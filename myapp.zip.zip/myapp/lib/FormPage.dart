import 'package:flutter/material.dart';
import 'package:intl/intl.dart';


void main() {
  runApp(MaterialApp(
    home: FormPage(),
    debugShowCheckedModeBanner: false,
  ));
}

class FormPage extends StatefulWidget {
  const FormPage({super.key});

  @override
  State<FormPage> createState() => _formpageState();
}

class _formpageState extends State<FormPage> {
  final TextEditingController _nameController = TextEditingController();
  String gender = 'Male';
  String? dob;
  String? selectedCountry;
  bool termsAgreed = false;
  List<String> selectedHobbies = [];
  List<String> countries = ['India', 'Italy', 'Germany', 'Japan'];
  List<String> hobbies = ['reading', 'swimming', 'dancing', 'racing'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Forms'),
        backgroundColor: Colors.blueGrey,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: ListView(
          children: [
            // Name
            TextFormField(
              controller: _nameController,
              decoration: const InputDecoration(
                labelText: 'Name',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.person),
              ),
            ),
            const SizedBox(height: 20),

            // Gender
            const Text('Gender'),
            Row(
              children: [
                Radio<String>(
                  value: 'Male',
                  groupValue: gender,
                  onChanged: (value) => setState(() => gender = value!),
                ),
                const Text('Male'),
                Radio<String>(
                  value: 'Female',
                  groupValue: gender,
                  onChanged: (value) => setState(() => gender = value!),
                ),
                const Text('Female'),
              ],
            ),
            const SizedBox(height: 20),

            // Date of Birth
            InkWell(
              onTap: () async {
                DateTime? pickedDate = await showDatePicker(
                  context: context,
                  initialDate: DateTime.now(),
                  firstDate: DateTime(2000),
                  lastDate: DateTime.now(),
                );

                if (pickedDate != null) {
                  setState(() {
                    dob =
                        "${pickedDate.day}/${pickedDate.month}/${pickedDate.year}";
                  });
                }
              },
              child: InputDecorator(
                decoration: const InputDecoration(
                  labelText: 'Date of Birth',
                  border: OutlineInputBorder(),
                ),
                child: Text(dob ?? 'Select Date'),
              ),
            ),
            const SizedBox(height: 20),

            // Country Dropdown
            DropdownButtonFormField<String>(
              decoration: const InputDecoration(
                labelText: 'Select Country',
                border: OutlineInputBorder(),
              ),
              value: selectedCountry,
              items: countries
                  .map((country) => DropdownMenuItem(
                        value: country,
                        child: Text(country),
                      ))
                  .toList(),
              onChanged: (value) => setState(() => selectedCountry = value),
            ),
            const SizedBox(height: 20),

            // Hobbies
            const Text('Hobbies'),
            ...hobbies.map((hobby) {
              return CheckboxListTile(
                title: Text(hobby),
                value: selectedHobbies.contains(hobby),
                onChanged: (value) {
                  setState(() {
                    if (value == true) {
                      selectedHobbies.add(hobby);
                    } else {
                      selectedHobbies.remove(hobby);
                    }
                  });
                },
              );
            }),
            const SizedBox(height: 16),

            // Terms Agreement
            CheckboxListTile(
              title: const Text('I agree to the terms'),
              value: termsAgreed,
              onChanged: (value) =>
                  setState(() => termsAgreed = value ?? false),
            ),
            const SizedBox(height: 20),

            // Submit Button
            ElevatedButton(
              onPressed: () {
                if (!termsAgreed) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('You must agree to the terms first!'),
                    ),
                  );
                  return;
                }

                // Submission logic
                String result = '''
Name: ${_nameController.text}
Gender: $gender
DOB: $dob
Country: $selectedCountry
Hobbies: ${selectedHobbies.join(', ')}
Agreed to Terms: $termsAgreed
''';
                showDialog(
                  context: context,
                  builder: (_) => AlertDialog(
                    title: const Text("Submitted Info"),
                    content: Text(result),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text("OK"),
                      )
                    ],
                  ),
                );
              },
              child: const Text('Submit'),
            ),
          ],
        ),
      ),
    );
  }
}
