import 'package:flutter/material.dart';

class BMWShowroom extends StatelessWidget {
  const BMWShowroom({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('BMW Cars Gallery'),
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView( // Enables vertical scroll
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              buildCard(
                title: 'BMW M4',
                description:
                    'High-performance coupe with 3.0L twin-turbo engine.',
                imageUrl:
                    'https://hips.hearstapps.com/hmg-prod/images/2025-bmw-m4-coupe-front-three-quarters-motion-65b935ea5dde6.jpg?crop=0.758xw:0.568xh;0.153xw,0.184xh&resize=1200:*',
              ),
              buildCard(
                title: 'BMW M3 GTR',
                description:
                    'Track-ready variant of the M3 made for racing.',
                imageUrl:
                    'https://www.gtplanet.net/wp-content/uploads/2024/11/image-1-38.jpg',
              ),
              buildCard(
                title: 'BMW M8',
                description:
                    'Luxury grand tourer with a twin-turbo V8 engine.',
                imageUrl:
                    'https://images.91wheels.com/news/wp-content/uploads/2022/01/2022-BMW-M8-facelift.jpg?w=1080&q=65',
              ),
              buildCard(
                title: 'BMW i8',
                description:
                    'Futuristic plug-in hybrid with unique styling.',
                imageUrl:
                    'https://cdn.motor1.com/images/mgl/QkXnP/s1/2020-bmw-i8-coupe.jpg',
              ),
              buildCard(
                title: 'BMW Z4',
                description:
                    'Two-seater convertible roadster with a sporty feel.',
                imageUrl:
                    'https://cdn.bmwblog.com/wp-content/uploads/2022/09/2023-bmw-z4-roadster-review-01.jpg',
              ),
              buildCard(
                title: 'BMW X6 M',
                description:
                    'High-performance SUV with coupe styling.',
                imageUrl:
                    'https://www.topgear.com/sites/default/files/cars-car/image/2022/08/bmw_x6m_competition_002.jpg',
              ),
              buildCard(
                title: 'BMW 7 Series',
                description:
                    'Ultimate luxury sedan with cutting-edge tech.',
                imageUrl:
                    'https://cdn.motor1.com/images/mgl/W0Vvw/s3/bmw-7-series.jpg',
              ),
              buildCard(
                title: 'BMW X5',
                description:
                    'Popular luxury SUV with strong on-road presence.',
                imageUrl:
                    'https://images.carandbike.com/car-images/colors/bmw/x5/bmw-x5-alpine-white.png?v=1638933181',
              ),
              buildCard(
                title: 'BMW M2',
                description:
                    'Compact, fun-to-drive sports coupe.',
                imageUrl:
                    'https://cdn.motor1.com/images/mgl/z6Wm8Z/s1/2023-bmw-m2.jpg',
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildCard({
    required String title,
    required String description,
    required String imageUrl,
  }) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 10),
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.lightBlue.shade100,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(color: Colors.grey.shade400, blurRadius: 6),
        ],
      ),
      padding: EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title,
              style: TextStyle(
                  fontSize: 22, fontWeight: FontWeight.bold, color: Colors.black)),
          SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                flex: 2,
                child: Text(
                  description,
                  style: TextStyle(color: Colors.black87),
                ),
              ),
              SizedBox(width: 10),
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.network(
                  imageUrl,
                  height: 100,
                  width: 130,
                  fit: BoxFit.cover,
                ),
              ),
            ],
          ),
        ],
     ),
);
}
}