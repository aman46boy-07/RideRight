import 'package:flutter/material.dart';
import 'package:myapp/titlebar.dart';
class SecondScreen extends StatelessWidget
{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
    
    //   appBar: AppBar(
    //     title: Text('Second Screen'),
    //     backgroundColor: Colors.amberAccent,
    //     foregroundColor: Colors.black26,
    // )
    appBar: commonAppBar('Second Screen'),
    body: Center(child: Image.network('https://bmw.scene7.com/is/image/BMW/g82_cs_ext_m-design-engine-bonnet_fb?qlt=80&wid=1024&fmt=webp',
    height:3000,
    width:1500,
    )
    )
   );
}
}