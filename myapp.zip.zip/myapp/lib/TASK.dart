import 'package:flutter/material.dart';

class CompanyPage extends StatelessWidget {
  const CompanyPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Company & Employees Info'),
        backgroundColor: Colors.blueGrey,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 🔹 Company Section
            const Text(
              'Company Information',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Container(
              height: 180,
              width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                image: const DecorationImage(
                  image: NetworkImage('https://logo.clearbit.com/microsoft.com'), // Replace with your Google image link
                  fit: BoxFit.contain,
                ),
              ),
            ),
            const SizedBox(height: 12),
            const Text(
              'Name: Microsoft Corporation',
              style: TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 6),
            const Text(
              'Description: Microsoft is a leading global technology company that develops software, services, devices, and solutions. It is known for products like Windows, Office, and Azure cloud.',
              style: TextStyle(fontSize: 16),
            ),
            const Divider(height: 30, thickness: 2),

            // 🔹 Employee Table Section
            const Text(
              'Employee Information',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Table(
              border: TableBorder.all(),
              columnWidths: const {
                0: FlexColumnWidth(2),
                1: FlexColumnWidth(2),
                2: FlexColumnWidth(2),
                3: FlexColumnWidth(1.5),
              },
              children: [
                _buildTableHeader(),
                _buildTableRow('Aman Naikwade', 'Manager', '₹90,000', 'EMP001'),
                _buildTableRow('Priya Sharma', 'Developer', '₹70,000', 'EMP002'),
                _buildTableRow('Amit Patel', 'Designer', '₹60,000', 'EMP003'),
                _buildTableRow('Sara Khan', 'HR', '₹50,000', 'EMP004'),
                _buildTableRow('David Singh', 'Tester', '₹55,000', 'EMP005'),
                _buildTableRow('Neha Raj', 'Support', '₹45,000', 'EMP006'),
                _buildTableRow('Ravi Gupta', 'Analyst', '₹65,000', 'EMP007'),
              ],
            )
          ],
        ),
      ),
    );
  }

  TableRow _buildTableHeader() {
    return const TableRow(
      decoration: BoxDecoration(color: Colors.blueGrey),
      children: [
        Padding(
          padding: EdgeInsets.all(8),
          child: Text('Name', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
        ),
        Padding(
          padding: EdgeInsets.all(8),
          child: Text('Position', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
        ),
        Padding(
          padding: EdgeInsets.all(8),
          child: Text('Salary', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
        ),
        Padding(
          padding: EdgeInsets.all(8),
          child: Text('ID No', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
        ),
      ],
    );
  }

  TableRow _buildTableRow(String name, String position, String salary, String id) {
    return TableRow(
      children: [
        Padding(padding: const EdgeInsets.all(8), child: Text(name)),
        Padding(padding: const EdgeInsets.all(8), child: Text(position)),
        Padding(padding: const EdgeInsets.all(8), child: Text(salary)),
        Padding(padding: const EdgeInsets.all(8), child: Text(id)),
     ],
);
}
}