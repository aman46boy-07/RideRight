import 'package:flutter/material.dart';
import 'package:myapp/table.dart'; // Make sure commonAppBar exists here
import 'package:myapp/titlebar.dart';
class TablePage extends StatelessWidget {
  const TablePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: commonAppBar('Student Table'), // Your custom app bar
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Table(
          border: TableBorder.all(),
          columnWidths: {
            0: FlexColumnWidth(2), // Name
            1: FlexColumnWidth(2), // ID
            2: FlexColumnWidth(2), // Marks
          },
          children: [
            TableRow(
              decoration: BoxDecoration(color: Colors.greenAccent),
              children: [
                buildCell('Name', isHeader: true),
                buildCell('ID', isHeader: true),
                buildCell('Marks', isHeader: true),
              ],
            ),
            TableRow(children: [
              buildCell('Amit'),
              buildCell('101'),
              buildCell('87'),
            ]),
            TableRow(children: [
              buildCell('Riya'),
              buildCell('102'),
              buildCell('93'),
            ]),
            TableRow(children: [
              buildCell('Sohan'),
              buildCell('103'),
              buildCell('76'),
            ]),
            TableRow(children: [
              buildCell('Priya'),
              buildCell('104'),
              buildCell('88'),
            ]),
          ],
        ),
      ),
    );
  }

  Widget buildCell(String text, {bool isHeader = false}) {
    return Padding(
      padding: EdgeInsets.all(10),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 16,
          fontWeight: isHeader ? FontWeight.bold : FontWeight.normal,
        ),
     ),
);
}
}