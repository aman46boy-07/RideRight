import 'package:flutter/material.dart';

void main() {
  runApp(const GemStoreApp());
}

class GemStoreApp extends StatelessWidget {
  const GemStoreApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'GemStore',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        scaffoldBackgroundColor: Colors.white,
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(30),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 12),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
      home: const WelcomeScreen(),
    );
  }
}

/* ----------------------------- WELCOME SCREEN ----------------------------- */

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Image.network(
            'https://www.datocms-assets.com/119921/1730301474-2025-bmw-m-1000-rr-review-details-price-spec_03.jpg?auto=format&w=800',
            width: double.infinity,
            height: double.infinity,
            fit: BoxFit.cover,
          ),
          Container(color: Colors.black.withOpacity(0.55)),
          Positioned(
            bottom: 100,
            left: 24,
            right: 24,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  'Welcome to BMWStore!',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 26,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'The home for a BMW',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 16, color: Colors.white70),
                ),
                const SizedBox(height: 32),
                Center(
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: Colors.black,
                    ),
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const SignupScreen()),
                    ),
                    child: const Text('Get Started'),
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}

/* ------------------------------- SIGNUP SCREEN ------------------------------- */

class SignupScreen extends StatelessWidget {
  const SignupScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final nameC = TextEditingController();
    final emailC = TextEditingController();
    final passC = TextEditingController();
    final confirmC = TextEditingController();

    return Scaffold(
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 60),
            const Text('Create',
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
            const Text('your account',
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
            const SizedBox(height: 30),
            TextField(controller: nameC, decoration: const InputDecoration(labelText: 'Enter your name')),
            const SizedBox(height: 15),
            TextField(controller: emailC, decoration: const InputDecoration(labelText: 'Email address')),
            const SizedBox(height: 15),
            TextField(
              controller: passC,
              obscureText: true,
              decoration: const InputDecoration(labelText: 'Password'),
            ),
            const SizedBox(height: 15),
            TextField(
              controller: confirmC,
              obscureText: true,
              decoration: const InputDecoration(labelText: 'Confirm password'),
            ),
            const SizedBox(height: 25),
            Center(
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.black),
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const IntroScreen1()),
                ),
                child: const Text('SIGN UP'),
              ),
            ),
            const SizedBox(height: 20),
            const Center(child: Text('or sign up with')),
            const SizedBox(height: 15),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Icon(Icons.apple),
                SizedBox(width: 28),
                Icon(Icons.facebook),
                SizedBox(width: 28),
                Icon(Icons.g_mobiledata),
              ],
            ),
            const SizedBox(height: 20),
            Center(
              child: TextButton(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const LoginScreen()),
                ),
                child: const Text('Already have an account? Log in'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/* ------------------------------- LOGIN SCREEN ------------------------------- */

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final emailC = TextEditingController();
    final passC = TextEditingController();

    return Scaffold(
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 60),
            const Text('Welcome back!',
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
            const SizedBox(height: 30),
            TextField(
              controller: emailC,
              decoration: const InputDecoration(labelText: 'Email address'),
            ),
            const SizedBox(height: 15),
            TextField(
              controller: passC,
              obscureText: true,
              decoration: const InputDecoration(labelText: 'Password'),
            ),
            const SizedBox(height: 25),
            Center(
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.black),
                onPressed: () {},
                child: const Text('LOGIN'),
              ),
            ),
            const SizedBox(height: 20),
            const Center(child: Text('or log in with')),
            const SizedBox(height: 15),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Icon(Icons.apple),
                SizedBox(width: 28),
                Icon(Icons.facebook),
                SizedBox(width: 28),
                Icon(Icons.g_mobiledata),
              ],
            ),
            const SizedBox(height: 20),
            Center(
              child: TextButton(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const SignupScreen()),
                ),
                child: const Text("Don't have an account? Sign up"),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/* ------------------------------- INTRO TEMPLATE ------------------------------- */

class IntroTemplate extends StatelessWidget {
  final String title, subtitle, imageUrl;
  final Widget? nextScreen;
  const IntroTemplate({
    super.key,
    required this.title,
    required this.subtitle,
    required this.imageUrl,
    this.nextScreen,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          const SizedBox(height: 90),
          Text(title,
              textAlign: TextAlign.center,
              style:
                  const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Text(subtitle,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 14, color: Colors.black54)),
          const SizedBox(height: 50),
          Container(
            height: 400,
            margin: const EdgeInsets.symmetric(horizontal: 40),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              color: Colors.grey[200],
              image: DecorationImage(
                image: NetworkImage(imageUrl),
                fit: BoxFit.cover,
              ),
            ),
          ),
          const Spacer(),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.black),
            onPressed: () {
              if (nextScreen != null) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => nextScreen!),
                );
              }
            },
            child: const Text('Shopping now'),
          ),
          const SizedBox(height: 40),
        ],
      ),
    );
  }
}

/* ------------------------------- INTRO SCREENS ------------------------------- */

class IntroScreen1 extends StatelessWidget {
  const IntroScreen1({super.key});
  @override
  Widget build(BuildContext context) {
    return const IntroTemplate(
      title: 'Discover new S1000rr',
      subtitle: 'Special new arrivals just for you',
      imageUrl: 'https://i.ytimg.com/vi/vKYPwiu-mOc/hq720.jpg',
      nextScreen: IntroScreen2(),
    );
  }
}

class IntroScreen2 extends StatelessWidget {
  const IntroScreen2({super.key});
  @override
  Widget build(BuildContext context) {
    return const IntroTemplate(
      title: 'Update S1000rr',
      subtitle: 'Favorite brand and color',
      imageUrl: 'https://imgd.aeplcdn.com/1280x720/n/4i850fb_1809701.jpg',
      nextScreen: IntroScreen3(),
    );
  }
}

class IntroScreen3 extends StatelessWidget {
  const IntroScreen3({super.key});
  @override
  Widget build(BuildContext context) {
    return const IntroTemplate(
      title: 'Upgraded model S1000rr',
      subtitle: 'Best choice of peoples',
      imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/7/79/BMW_S1000_RR_Studio.JPG',
      nextScreen: LoginScreen(),
);
}
}