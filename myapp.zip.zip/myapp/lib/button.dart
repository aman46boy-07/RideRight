import 'package:flutter/material.dart';

void main() {
  runApp(const LimitedButtonShowcaseApp());
}

class LimitedButtonShowcaseApp extends StatelessWidget {
  const LimitedButtonShowcaseApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Essential Buttons',
      theme: ThemeData(
        primarySwatch: Colors.blueGrey,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: const EssentialButtonsScreen(),
    );
  }
}

class EssentialButtonsScreen extends StatefulWidget {
  const EssentialButtonsScreen({super.key});

  @override
  State<EssentialButtonsScreen> createState() => _EssentialButtonsScreenState();
}

class _EssentialButtonsScreenState extends State<EssentialButtonsScreen> {
  String _lastAction = 'None';
  String? _selectedOption; // State for DropdownButton

  final List<String> _options = ['Option A', 'Option B', 'Option C', 'Option D'];

  void _updateAction(String actionName) {
    setState(() {
      _lastAction = actionName;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('$actionName performed!'),
        duration: const Duration(milliseconds: 800),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Essential Flutter Buttons'),
        actions: [
          // IconButton in AppBar
          IconButton(
            icon: const Icon(Icons.info_outline),
            tooltip: 'App Info',
            onPressed: () => _updateAction('Info Icon Button'),
          ),
        ],
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              // Display last action with a Text widget
              Text(
                'Last Action: $_lastAction',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 30),

              // 1. ElevatedButton
              const Text('Elevated Button:', style: TextStyle(fontSize: 16)),
              const SizedBox(height: 10),
              ElevatedButton(
                onPressed: () => _updateAction('Elevated Button'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.deepPurple,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                ),
                child: const Text('Submit Data'),
              ),
              const SizedBox(height: 30),

              // 2. OutlinedButton
              const Text('Outlined Button:', style: TextStyle(fontSize: 16)),
              const SizedBox(height: 10),
              OutlinedButton(
                onPressed: () => _updateAction('Outlined Button'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.teal,
                  side: const BorderSide(color: Colors.teal, width: 2),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: const Text('View Details'),
              ),
              const SizedBox(height: 30),

              // 3. DropdownButton
              const Text('Dropdown Button:', style: TextStyle(fontSize: 16)),
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.blueGrey, width: 1.5),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: DropdownButtonHideUnderline( // Hides default underline
                  child: DropdownButton<String>(
                    value: _selectedOption,
                    hint: const Text('Select an Option'),
                    onChanged: (String? newValue) {
                      setState(() {
                        _selectedOption = newValue;
                      });
                      _updateAction('Dropdown Button: $newValue');
                    },
                    items: _options.map<DropdownMenuItem<String>>((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(value),
                      );
                    }).toList(),
                    isExpanded: true, // Makes the dropdown take available width
                    icon: const Icon(Icons.arrow_drop_down_circle),
                    iconEnabledColor: Colors.blueGrey,
                  ),
                ),
              ),
              const SizedBox(height: 30),

              // 4. IconButton
              const Text('Icon Button:', style: TextStyle(fontSize: 16)),
              const SizedBox(height: 10),
              IconButton(
                icon: const Icon(Icons.notifications_active),
                iconSize: 40,
                color: Colors.orange,
                tooltip: 'Show Notifications',
                onPressed: () => _updateAction('Notification Icon Button'),
              ),
            ],
          ),
        ),
     ),
);
}
}