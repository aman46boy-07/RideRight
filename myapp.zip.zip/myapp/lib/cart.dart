import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Checkout Form',
      debugShowCheckedModeBanner: false,
      home: const CheckoutForm(),
    );
  }
}

class CheckoutForm extends StatefulWidget {
  const CheckoutForm({super.key});

  @override
  State<CheckoutForm> createState() => _CheckoutFormState();
}

class _CheckoutFormState extends State<CheckoutForm> {
  String? _selectedCard = 'VISA';

  InputDecoration customInput(String hint) {
    return InputDecoration(
      hintText: hint,
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(4),
        borderSide: const BorderSide(color: Colors.grey),
      ),
    );
  }

  Widget buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Text(
        title,
        style: const TextStyle(
            fontWeight: FontWeight.bold, fontSize: 16, color: Colors.black87),
      ),
    );
  }

  Widget buildCardType(String value, String label, String imageUrl) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Radio<String>(
          value: value,
          groupValue: _selectedCard,
          onChanged: (val) {
            setState(() {
              _selectedCard = val;
            });
          },
        ),
        Image.network(imageUrl, height: 20),
        const SizedBox(width: 4),
        Text(label),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFA2C857),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Container(
            width: 400,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFFA2C857),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                buildSectionTitle('Step 1: Your details'),
                TextField(decoration: customInput('First and last name')),
                const SizedBox(height: 10),
                TextField(decoration: customInput('example@domain.com')),
                const SizedBox(height: 10),
                TextField(decoration: customInput('Eg. +')),
                buildSectionTitle('Step 2: Delivery address'),
                TextField(
                  decoration: customInput(''),
                  maxLines: 4,
                ),
                const SizedBox(height: 10),
                TextField(decoration: customInput('Post code')),
                const SizedBox(height: 10),
                TextField(decoration: customInput('Country')),

                buildSectionTitle('Step 3: Card details'),
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: const Color(0xFFB3D76A),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: [
                      buildCardType(
                        'VISA',
                        'VISA',
                        'https://upload.wikimedia.org/wikipedia/commons/4/41/Visa_Logo.png',
                      ),
                      buildCardType(
                        'AMEX',
                        'AmEx',
                        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTi8Jsq4EATKruHpqE2vwrFaaY0Il1mCdnpnw&s',
                      ),
                      buildCardType(
                        'MASTERCARD',
                        'Mastercard',
                        'https://upload.wikimedia.org/wikipedia/commons/0/04/Mastercard-logo.png',
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                TextField(decoration: customInput('Card number')),
                const SizedBox(height: 10),
                TextField(decoration: customInput('Security code')),
                const SizedBox(height: 10),
                TextField(decoration: customInput('Exact name as on the card')),

                const SizedBox(height: 20),
                Center(
                  child: ElevatedButton(
                    onPressed: () {},
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.black,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(25),
                      ),
                      padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 14),
                    ),
                    child: const Text(
                      'BUY IT!',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.2,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
     ),
);
}
}