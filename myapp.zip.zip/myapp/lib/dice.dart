import 'package:flutter/material.dart';

void main() {
  runApp(const CardWidget());
}

class CardWidget extends StatelessWidget {
  const CardWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text(
          'HOME',
          style: TextStyle(
            fontFamily: 'libertinus',
            fontSize: 25,
            color: Color.fromARGB(255, 191, 211, 246),
          ),
        ),
        backgroundColor: Colors.white,
      ),
      backgroundColor: const Color.fromARGB(255, 191, 211, 246),
      body: Center(
        child: Card(
          elevation: 50,
          shadowColor: Colors.black87,
          color: Colors.greenAccent[700],
          child: SizedBox(
            height: 500,
            width: 300,
            child: Padding(
              padding: EdgeInsets.all(20.0),
              child: Column(
                children: [
                  CircleAvatar(
                    radius: 25,
                    backgroundImage: NetworkImage(
                      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQfN5RMUrmAk_LVnzCA-wLQnA99UoYtqQ8LAjlSPAzENNTSG_kzhLWwi7_EC6cPZmmsuVk&usqp=CAU',
                    ),
                    backgroundColor: Colors.transparent,
                    //backgroundColor: Colors.blueAccent),
    ),
                  SizedBox(height: 25),
                  Text('BMW MOTORRAD'),
                  SizedBox(height: 25),
                  Text(
                    'Text(String data, {Key? key, TextStyle? style, StrutStyle? strutStyle, TextAlign? textAlign, TextDirection? textDirection, Locale? locale, bool? softWrap, TextOverflow? overflow, double? textScaleFactor, TextScaler? textScaler, int? maxLines, String? semanticsLabel, String? semanticsIdentifier, TextWidthBasis? textWidthBasis, TextHeightBehavior? textHeightBehavior, Color? selectionColor})',
                  ),
                  ElevatedButton(
                    onPressed: () {},
                    child: Row(
                      children: [Icon(Icons.arrow_forward), Text('See More')],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
     ),
);
}
}