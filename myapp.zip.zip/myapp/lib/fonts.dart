import 'package:flutter/material.dart';
import 'package:flutter_animated_splash/flutter_animated_splash.dart';

void main() {
  runApp(const AnimationApp());
}

class AnimationApp extends StatelessWidget {
  const AnimationApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: AnimatedSplash(
        type: Transition.fade,
        durationInSeconds: 5,
        curve: Curves.fastEaseInToSlowEaseOut,
        navigator: AnimationScreen(),
        backgroundColor: Colors.white,
        child: Text(
          'ANIMATED DEMO',
          style: TextStyle(fontSize: 25, color: Colors.blueAccent),
        ),
      ),
    );
  }
}

class AnimationScreen extends StatelessWidget {
  const AnimationScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'FONT USE',
          style: TextStyle(
            fontFamily: 'LibertinusFont',
            fontSize: 35,
            color: Colors.white,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.blueAccent,
      ),
      backgroundColor: const Color.fromARGB(255, 227, 161, 161),
);
}
}