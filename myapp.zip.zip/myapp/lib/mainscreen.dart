import 'package:flutter/material.dart';
import 'package:myapp/SecondScreen.dart';
import 'package:myapp/titlebar.dart';
class mainscreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // appBar: AppBar(
      //   title: Text('Demo Page'),
      //   backgroundColor: Colors.amber,
      //   foregroundColor: Colors.black26,
      // ),
      appBar: commonAppBar('demo'),
      body: Center(
        child: ElevatedButton(
          onPressed : (){
          Navigator.push(
            context,
            MaterialPageRoute(builder:(Context)=> SecondScreen()),
          );
          },
        child :Text('My Button'),
      ),
     ),
);
}
}
