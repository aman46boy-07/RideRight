import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';

class SliderClass extends StatelessWidget {
  const SliderClass({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, String>> imgList = [
      {
        "img":
            'https://cdn.bikedekho.com/processedimages/bmw/s1000rr/640X309/s1000rr63944bddea0d4.jpg',
        "title": 'BMW S1000rr',
        "buttonText": "Click here",
      },
      {
        "img":
            'https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSkQDon-dUhuKcCk5UB-9NkETExGwCAjx6AUZk3EBkVfCU0AsDVoJrqRkYu2r92z8_jfqmjvUONzPynD_fztSJBqRRLP8xF1gksSkGtPg',
        "title": 'unsymmetric s1000',
        "buttonText": "Click here",
      },
      {
        "img":
            'https://images.carandbike.com/bike-images/big/yamaha/yzf-r1m/yamaha-yzf-r1m.jpg?v=6',
        "title": 'Goku',
        "buttonText": "Click here",
      },
      {
        "img":
            'https://static.wikia.nocookie.net/vinlandsaga/images/2/27/Thorfinn_S2_Design.png',
        "title": 'Thorfinn',
        "buttonText": "Click here",
      },
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Image Slider')),
      body: Center(
        child: CarouselSlider(
          items: imgList.map((items) {
            return Stack(
              alignment: Alignment.bottomCenter,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Image.network(
                    items['img']!,
                    fit: BoxFit.cover,
                    width: 1000,
                    loadingBuilder: (context, child, loadingProgress) {
                      if (loadingProgress == null) return child;
                      return const Center(child: CircularProgressIndicator());
                    },
                    errorBuilder: (context, error, stackTrace) =>
                        const Center(child: Text("Image not available")),
                  ),
                ),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(10),
                  color: Colors.black54,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        items['title']!,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 5),
                      ElevatedButton(
                        onPressed: () {
                          // Action for button
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text('${items['title']} clicked')),
                          );
                        },
                        child: Text(items['buttonText']!),
                      ),
                    ],
                  ),
                )
              ],
            );
          }).toList(),
          options: CarouselOptions(
            height: 400,
            autoPlay: true,
            enableInfiniteScroll: true,
            enlargeCenterPage: true,
          ),
        ),
      ),
    );
  }
}
