import 'package:flutter/material.dart';
import 'package:myapp/table.dart';
class MainScreen extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
appBar: AppBar(title:Text('DEMO') ,centerTitle: true,), 
body: Center(
  child:ElevatedButton(
    onPressed:(){Navigator.push(
      context, 
      PageRouteBuilder(
        pageBuilder: (context, animation, secondaryAnimation)=> TablePage(),
        transitionsBuilder: (context, animation, secondaryAnimation, child){
        return RotationTransition(
          turns: animation,
          child: ScaleTransition(
            scale: animation,
            child: child,
            
            ),
          );
      
      /*  return ScaleTransition(
        scale:animation,
        child: child,
        ); */
       
       
        /*  return FadeTransition(
          opacity: animation,
          child: child,
          ); */
        
        
          /* const begin= Offset(1.0, 0.0);
          const end = Offset.zero;
          const curve = Curves.ease;
          final tween = Tween(
            begin: begin, end: end
          ).chain(CurveTween(curve: curve));
          return SlideTransition(
            position:animation.drive(tween),
            child: child,
            ); */
                 },
        )
    );
    },
     child: Text("button"),
     ),
),
    );
  }
}