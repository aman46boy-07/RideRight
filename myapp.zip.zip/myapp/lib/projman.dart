import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class ProjectManagementForm extends StatefulWidget {
  const ProjectManagementForm({super.key});

  @override
  State<ProjectManagementForm> createState() => _ProjectManagementFormState();
}

class _ProjectManagementFormState extends State<ProjectManagementForm> {
  final TextEditingController projectNameController = TextEditingController();
  final TextEditingController descriptionController = TextEditingController();

  DateTime? startDate;
  DateTime? endDate;
  String? assignedTo;
  String? priority;

  final List<String> teamMembers = ['Er Merry Petision', 'John Doe', 'Jane Smith'];

  Future<void> _selectDate(bool isStartDate) async {
    final pickedDate = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );

    if (pickedDate != null) {
      setState(() {
        if (isStartDate) {
          startDate = pickedDate;
        } else {
          endDate = pickedDate;
        }
      });
    }
  }

  void _clearForm() {
    setState(() {
      projectNameController.clear();
      descriptionController.clear();
      startDate = null;
      endDate = null;
      assignedTo = null;
      priority = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white, // ✅ screen background
      body: Center(
        child: SingleChildScrollView(
          child: Container(
            width: 600,
            padding: const EdgeInsets.all(30),
            decoration: BoxDecoration(
              color: Colors.cyanAccent, // ✅ blue box
              borderRadius: BorderRadius.circular(8),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Text(
                    'Project Management',
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      decoration: TextDecoration.underline,
                    ),
                  ),
                ),
                const SizedBox(height: 30),

                _buildLabel("Project Name"),
                TextField(
                  controller: projectNameController,
                  decoration: _inputDecoration("project name"),
                ),
                const SizedBox(height: 20),

                _buildLabel("Assigned to"),
                DropdownButtonFormField<String>(
                  value: assignedTo,
                  decoration: _inputDecoration("Select member"),
                  items: teamMembers.map((member) {
                    return DropdownMenuItem(value: member, child: Text(member));
                  }).toList(),
                  onChanged: (val) => setState(() => assignedTo = val),
                ),
                const SizedBox(height: 20),

                _buildLabel("Start Date"),
                _datePickerField(startDate, true),
                const SizedBox(height: 20),

                _buildLabel("End Date"),
                _datePickerField(endDate, false),
                const SizedBox(height: 20),

                _buildLabel("Priority"),
                Row(
                  children: [
                    _buildRadio("High"),
                    _buildRadio("Average"),
                    _buildRadio("Low"),
                  ],
                ),
                const SizedBox(height: 20),

                _buildLabel("Description"),
                TextField(
                  controller: descriptionController,
                  maxLines: 3,
                  decoration: _inputDecoration(""),
                ),
                const SizedBox(height: 30),

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    ElevatedButton(
                      onPressed: () {
                        // Submit logic here
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                      ),
                      child: const Text("Submit"),
                    ),
                    ElevatedButton(
                      onPressed: _clearForm,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blue,
                      ),
                      child: const Text("Clear"),
                    ),
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLabel(String label) {
    return Text(label, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16));
  }

  InputDecoration _inputDecoration(String hint) {
    return InputDecoration(
      hintText: hint,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(4)),
      contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
    );
  }

  Widget _datePickerField(DateTime? date, bool isStartDate) {
    return GestureDetector(
      onTap: () => _selectDate(isStartDate),
      child: InputDecorator(
        decoration: _inputDecoration("dd - mm - yyyy"),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              date == null ? "dd - mm - yyyy" : DateFormat('dd - MM - yyyy').format(date),
            ),
            const Icon(Icons.calendar_today),
          ],
        ),
      ),
    );
  }

  Widget _buildRadio(String value) {
    return Row(
      children: [
        Radio<String>(
          value: value,
          groupValue: priority,
          onChanged: (val) => setState(() => priority = val),
        ),
        Text(value),
        const SizedBox(width: 10),
     ],
);
}
}