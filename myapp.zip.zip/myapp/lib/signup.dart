import 'package:flutter/material.dart';

void main() {
  runApp(const LoginSignupApp());
}

class LoginSignupApp extends StatelessWidget {
  const LoginSignupApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: LoginSignupPage(),
    );
  }
}

class LoginSignupPage extends StatefulWidget {
  const LoginSignupPage({super.key});

  @override
  State<LoginSignupPage> createState() => _LoginSignupPageState();
}

class _LoginSignupPageState extends State<LoginSignupPage> {
  bool isLogin = true;

  InputDecoration customInput(String hint) {
    return InputDecoration(
      hintText: hint,
      filled: true,
      fillColor: const Color(0xFFF2F2F2),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide.none,
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
    );
  }

  Widget gradientButton(String text, VoidCallback onTap) {
    return Container(
      height: 50,
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF1E3C72), Color(0xFF2A5298)],
        ),
        borderRadius: BorderRadius.circular(12),
      ),
      child: ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        child: Text(
          text,
          style: const TextStyle(
              fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 1),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFBFB8EC),
      body: Center(
        child: Container(
          width: 360,
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(24),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                isLogin ? 'Login Form' : 'Signup Form',
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 22,
                ),
              ),
              const SizedBox(height: 20),

              // Toggle Button
              Container(
                height: 45,
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey.shade300),
                  borderRadius: BorderRadius.circular(30),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: () => setState(() => isLogin = true),
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: isLogin
                                ? const LinearGradient(
                                    colors: [Color(0xFF1E3C72), Color(0xFF2A5298)],
                                  )
                                : null,
                            color: isLogin ? null : Colors.transparent,
                            borderRadius: BorderRadius.circular(30),
                          ),
                          alignment: Alignment.center,
                          child: Text(
                            'Login',
                            style: TextStyle(
                              color: isLogin ? Colors.white : Colors.black87,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      child: GestureDetector(
                        onTap: () => setState(() => isLogin = false),
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: !isLogin
                                ? const LinearGradient(
                                    colors: [Color(0xFF1E3C72), Color(0xFF2A5298)],
                                  )
                                : null,
                            color: !isLogin ? null : Colors.transparent,
                            borderRadius: BorderRadius.circular(30),
                          ),
                          alignment: Alignment.center,
                          child: Text(
                            'Signup',
                            style: TextStyle(
                              color: !isLogin ? Colors.white : Colors.black87,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 24),

              // Email
              TextField(decoration: customInput('Email Address')),
              const SizedBox(height: 16),

              // Password
              TextField(
                obscureText: true,
                decoration: customInput('Password'),
              ),
              const SizedBox(height: 16),

              // Confirm password only on signup
              if (!isLogin)
                TextField(
                  obscureText: true,
                  decoration: customInput('Confirm password'),
                ),

              // Forgot password only on login
              if (isLogin)
                Align(
                  alignment: Alignment.centerRight,
                  child: TextButton(
                    onPressed: () {},
                    child: const Text(
                      'Forgot password?',
                      style: TextStyle(color: Colors.blue),
                    ),
                  ),
                ),

              const SizedBox(height: 10),

              // Button
              gradientButton(isLogin ? "Login" : "Signup", () {
                // Submit form
              }),

              const SizedBox(height: 18),

              // Switch text
              RichText(
                text: TextSpan(
                  text: isLogin
                      ? 'Not a member? '
                      : 'Already have an account? ',
                  style: const TextStyle(color: Colors.black87),
                  children: [
                    TextSpan(
                      text: isLogin ? 'Signup now' : 'Login now',
                      style: const TextStyle(
                        color: Colors.blueAccent,
                        fontWeight: FontWeight.bold,
                      ),
                      // Optional: add gesture recognizer
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
     ),
);
}
}