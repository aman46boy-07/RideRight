import 'package:flutter/material.dart';

class CardsScreen extends StatelessWidget {
  const CardsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:SingleChildScrollView(
       child: Center(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                margin: EdgeInsets.only(top: 20),
                decoration: BoxDecoration(
                  color: Colors.lightBlue,
                  borderRadius: BorderRadius.circular(5),
                ),
                height: 220,
                width: 440,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text('BMW M4',style: TextStyle(fontSize: 25)),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 280,
                          child: Text(
                            'TBMW M4 Competition Specifications - Dimensions ...The BMW M4 Competition is a high-performance sports coupe known for its powerful engine, dynamic handling, and aggressive styling. It features a 3.0-liter ',
                          ),
                        ),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(100),
                          child: Image.network(
                            'https://hips.hearstapps.com/hmg-prod/images/2025-bmw-m4-coupe-front-three-quarters-motion-65b935ea5dde6.jpg?crop=0.758xw:0.568xh;0.153xw,0.184xh&resize=1200:*',
                            height: 150,
                            width: 150,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                decoration: BoxDecoration(
                  color: Colors.lightBlue,
                  borderRadius: BorderRadius.circular(30),
                ),
                height: 220,
                width: 440,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text('BMW M3 GTR',style: TextStyle(fontSize: 25)),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 280,
                          child: Text(
                            'The BMW M3 GTR is a high-performance variant of the BMW M3, originally developed for racing and later adapted for street use. It'
                          ),
                        ),
                        Image.network(
                          'https://www.gtplanet.net/wp-content/uploads/2024/11/image-1-38.jpg',
                          height: 150,
                          width: 120,
                          fit: BoxFit.cover,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Container(
                margin: EdgeInsets.only(bottom: 20),
                decoration: BoxDecoration(
                  color: Colors.lightBlue,
                  borderRadius: BorderRadius.circular(50),
                ),
                height: 220,
                width: 440,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text('BMW M8',style: TextStyle(fontSize: 25)),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 260,
                          child: Text(
                            'The BMW M8 is a high-performance luxury sports car, available as a coupe, convertible, or Gran Coupe. It features a powerful M TwinPower Turbo V8 engine, delivering impressive acceleration and speed. The M8 also boasts advanced technology and luxurious interior features.',
                          ),
                        ),
                        Image.network(
                          'https://images.91wheels.com/news/wp-content/uploads/2022/01/2022-BMW-M8-facelift.jpg?w=1080&q=65',
                          height: 150,
                          width: 130,
                          fit: BoxFit.cover,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
       ),
     ),
      ),
);
}
}