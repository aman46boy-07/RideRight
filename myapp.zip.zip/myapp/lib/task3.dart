import 'package:flutter/material.dart';
import 'task3.dart';

class WorldCupPage extends StatelessWidget {
  const WorldCupPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('World Cup 2023'),
        backgroundColor: Colors.green[800],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // 🔹 Banner Image
          SizedBox(
            height: 900,
            width: double.infinity,
            child: Image.network(
              'https://tse2.mm.bing.net/th/id/OIP.Z2kXutsi3y4nySfAIgeaUgHaHa?r=0&rs=1&pid=ImgDetMain&o=7&rm=3',
              fit: BoxFit.cover,
            ),
          ),
          const SizedBox(height: 25),

          // 🔹 Heading & Paragraph
          const Text(
            'ICC Cricket World Cup 2023',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          const Text(
            'The 2023 ICC Cricket World Cup was hosted by India. Teams from around the world competed for the prestigious title in exciting matches full of passion, drama, and world-class cricket performances.',
            style: TextStyle(fontSize: 16),
          ),
          const Divider(height: 30, thickness: 2),

          // 🔹 Team Table
          const Text(
            'Team Standings',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          Table(
            border: TableBorder.all(),
            columnWidths: const {
              0: FlexColumnWidth(2),
              1: FlexColumnWidth(2),
              2: FlexColumnWidth(1.5),
              3: FlexColumnWidth(2),
              4: FlexColumnWidth(1.2),
              5: FlexColumnWidth(1.2),
            },
            children: [
              _buildTableHeader(),
              _buildTeamRow(
                'India',
                'https://flagcdn.com/w320/in.png',
                '14',
                '+1.521',
                '7',
                '0',
              ),
              _buildTeamRow(
                'Australia',
                'https://flagcdn.com/w320/au.png',
                '12',
                '+0.841',
                '6',
                '1',
              ),
              _buildTeamRow(
                'South Africa',
                'https://flagcdn.com/w320/za.png',
                '10',
                '+1.234',
                '5',
                '2',
              ),
              _buildTeamRow(
                'New Zealand',
                'https://flagcdn.com/w320/nz.png',
                '8',
                '+0.672',
                '4',
                '3',
              ),
              _buildTeamRow(
                'England',
                'https://flagcdn.com/w320/gb.png',
                '6',
                '-0.456',
                '3',
                '4',
              ),
            ],
          ),

          const Divider(height: 30, thickness: 2),

          // 🔹 Top Performers Lists
          const Text(
            'Top Performers',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),

          // Most Runs
          _buildListSection(
            'Most Runs',
            ['Virat Kohli - 765', 'Rohit Sharma - 588', 'Quinton de Kock - 549'],
          ),

          // Most Wickets
          _buildListSection(
            'Most Wickets',
            ['Mohammed Shami - 24', 'Adam Zampa - 23', 'Dilshan Madushanka - 21'],
          ),

          // Most Catches
          _buildListSection(
            'Most Catches',
            ['David Warner - 9', 'Ravindra Jadeja - 8', 'Ben Stokes - 7'],
          ),
        ]),
      ),
    );
  }

  TableRow _buildTableHeader() {
    return const TableRow(
      decoration: BoxDecoration(color: Colors.green),
      children: [
        Padding(
          padding: EdgeInsets.all(8),
          child: Text('Team Name', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
        ),
        Padding(
          padding: EdgeInsets.all(8),
          child: Text('Flag', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
        ),
        Padding(
          padding: EdgeInsets.all(8),
          child: Text('Points', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
        ),
        Padding(
          padding: EdgeInsets.all(8),
          child: Text('Run Rate', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
        ),
        Padding(
          padding: EdgeInsets.all(8),
          child: Text('Win', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
        ),
        Padding(
          padding: EdgeInsets.all(8),
          child: Text('Lose', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
        ),
      ],
    );
  }

  TableRow _buildTeamRow(String team, String flagUrl, String points, String rate, String win, String lose) {
    return TableRow(children: [
      Padding(padding: const EdgeInsets.all(8), child: Text(team)),
      Padding(
        padding: const EdgeInsets.all(8),
        child: Image.network(flagUrl, height: 25),
      ),
      Padding(padding: const EdgeInsets.all(8), child: Text(points)),
      Padding(padding: const EdgeInsets.all(8), child: Text(rate)),
      Padding(padding: const EdgeInsets.all(8), child: Text(win)),
      Padding(padding: const EdgeInsets.all(8), child: Text(lose)),
    ]);
  }

  Widget _buildListSection(String title, List<String> items) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
        const SizedBox(height: 6),
        ...items.map((e) => Text('• $e', style: const TextStyle(fontSize: 16))).toList(),
      ]),
);
}
}