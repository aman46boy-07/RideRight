import 'package:flutter/material.dart';
import 'task4.dart';

class task4 extends StatelessWidget {
  const task4({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Task 4 - Card & Image Table'),
        backgroundColor: Colors.deepPurple,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // 🔹 CARD SECTION
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  // Background Image
                  Container(
                    height: 250,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      image: const DecorationImage(
                        image: NetworkImage(
                          'https://images.unsplash.com/photo-1507525428034-b723cf961d3e',
                        ),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  // Overlay
                  Container(
                    height: 250,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: Colors.black.withOpacity(0.4),
                    ),
                  ),
                  // Content
                  Column(
                    children: [
                      const Text(
                        'Nature Card',
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                      const SizedBox(height: 6),
                      const Text(
                        'A beautiful scenery that inspires calmness and peace.',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 16, color: Colors.white),
                      ),
                      const SizedBox(height: 16),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(100),
                        child: Image.network(
                          'https://images.unsplash.com/photo-1610878180933-cd3b33e7f579',
                          height: 80,
                          width: 80,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 30),

            // 🔹 TABLE HEADING
            const Padding(
              padding: EdgeInsets.all(12.0),
              child: Text(
                'Image Table (12 Columns × 3 Rows)',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ),

            // 🔹 IMAGE TABLE
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: Table(
                border: TableBorder.all(color: Colors.grey),
                columnWidths: {
                  0: const FlexColumnWidth(1),
                  1: const FlexColumnWidth(1),
                  2: const FlexColumnWidth(1),
                  3: const FlexColumnWidth(1),
                  4: const FlexColumnWidth(1),
                  5: const FlexColumnWidth(1),
                  6: const FlexColumnWidth(1),
                  7: const FlexColumnWidth(1),
                  8: const FlexColumnWidth(1),
                  9: const FlexColumnWidth(1),
                  10: const FlexColumnWidth(1),
                  11: const FlexColumnWidth(1),
                },
                children: [
                  _buildImageRow([
                    'https://picsum.photos/id/101/100',
                    'https://picsum.photos/id/102/100',
                    'https://picsum.photos/id/103/100',
                    'https://picsum.photos/id/104/100',
                    'https://picsum.photos/id/105/100',
                    'https://picsum.photos/id/106/100',
                    'https://picsum.photos/id/107/100',
                    'https://picsum.photos/id/108/100',
                    'https://picsum.photos/id/109/100',
                    'https://picsum.photos/id/110/100',
                    'https://picsum.photos/id/111/100',
                    'https://picsum.photos/id/112/100',
                  ]),
                  _buildImageRow([
                    'https://picsum.photos/id/113/100',
                    'https://picsum.photos/id/114/100',
                    'https://picsum.photos/id/115/100',
                    'https://picsum.photos/id/116/100',
                    'https://picsum.photos/id/117/100',
                    'https://picsum.photos/id/118/100',
                    'https://picsum.photos/id/119/100',
                    'https://picsum.photos/id/120/100',
                    'https://picsum.photos/id/121/100',
                    'https://picsum.photos/id/122/100',
                    'https://picsum.photos/id/123/100',
                    'https://picsum.photos/id/124/100',
                  ]),
                  _buildImageRow([
                    'https://picsum.photos/id/125/100',
                    'https://picsum.photos/id/126/100',
                    'https://picsum.photos/id/127/100',
                    'https://picsum.photos/id/128/100',
                    'https://picsum.photos/id/129/100',
                    'https://picsum.photos/id/130/100',
                    'https://picsum.photos/id/131/100',
                    'https://picsum.photos/id/132/100',
                    'https://picsum.photos/id/133/100',
                    'https://picsum.photos/id/134/100',
                    'https://picsum.photos/id/135/100',
                    'https://picsum.photos/id/136/100',
                  ]),
                ],
              ),
            ),

            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }

  // 🔹 Build one image row
  static TableRow _buildImageRow(List<String> urls) {
    return TableRow(
      children: urls.map((url) => _buildImageCell(url)).toList(),
    );
  }

  // 🔹 Build each image cell
  static Widget _buildImageCell(String imageUrl) {
    return Padding(
      padding: const EdgeInsets.all(4.0),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child: Image.network(
          imageUrl,
          height: 60,
          width: 60,
          fit: BoxFit.cover,
        ),
     ),
);
}
}