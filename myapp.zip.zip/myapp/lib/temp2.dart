import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: BMWFactPage(),
    );
  }
}

class BMWFactPage extends StatelessWidget {
  const BMWFactPage({super.key});

  void navigateToDetail(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const BMWDetailPage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('BMW M4 Competition'),
        backgroundColor: Colors.lightBlueAccent,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () => navigateToDetail(context),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.black,
                foregroundColor: Colors.cyan,
              ),
              child: const Text('Engine Specs'),
            ),
            const SizedBox(height: 15),
            ElevatedButton(
              onPressed: () => navigateToDetail(context),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.black,
                foregroundColor: Colors.green,
              ),
              child: const Text('Top Speed'),
            ),
            const SizedBox(height: 15),
            ElevatedButton(
              onPressed: () => navigateToDetail(context),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.black,
                foregroundColor: Colors.yellow,
              ),
              child: const Text('Horsepower'),
            ),
            const SizedBox(height: 15),
            ElevatedButton(
              onPressed: () => navigateToDetail(context),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.black,
                foregroundColor: Colors.red,
              ),
              child: const Text('Price Info'),
            ),
          ],
        ),
      ),
    );
  }
}

class BMWDetailPage extends StatelessWidget {
  const BMWDetailPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('BMW M4 Details'),
        backgroundColor: Colors.red,
      ),
      body: const Center(
        child: Text(
          'BMW M4 Competition\n3.0L Twin Turbo Engine\n503 HP\n0-100 km/h in 3.8s\nTop Speed: 290 km/h+\n price: 1.77cr',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 20),
        ),
      ),
    );
  }
}
