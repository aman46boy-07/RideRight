import 'package:flutter/material.dart';

PreferredSizeWidget commonAppBar(String title){
  return AppBar(
    title: Text(title),
    centerTitle: true,
    backgroundColor: Colors.yellow,
    foregroundColor: Colors.black,
    actions: [
      IconButton(icon: Icon(Icons.abc),onPressed: (){}

)],
);
}